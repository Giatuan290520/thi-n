<script language="javascript" src="http://www.vnexpress.net/service/Gold_Content.js"></script>
<link href="../css/style.css" rel="stylesheet" type="text/css" />

<table width="140" border="1" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF" bordercolor="#666666" style="border-collapse:collapse" id="table4535">
                      <tr>
                        <td width="48%" bgcolor="#FFFFFF"><div align="center">&nbsp;<?php echo $_lang=='vn'?'<b>Mua</b>':'<b>Buy</b>'?></div></td>
                        <td width="52%" height="20" bgcolor="#FFFFFF"><div align="center"><script language="javascript">document.write(vGoldSbjBuy);</script>&nbsp;</div></td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><div align="center">&nbsp;<?php echo $_lang=='vn'?'<b>Bán</b>':'<b>Sell</b>'?></div></td>
                        <td height="20" bgcolor="#FFFFFF"><div align="center"><script language="javascript">document.write(vGoldSjcSell);</script>&nbsp;</div></td>
                      </tr>
</table>