<?php

$hostname     = "localhost";
$username     = "qua59_admin";
$password     = "quangvinh";
$databasename = "qua59b77_amnhac";
$visitorTimeout = 900; // =15 * 60 Download source mien phi tai Sharecode.vn

$MAXPAGE = 10;
$multiLanguage = 1;//0 : single  ;  1 : multi

$arrLanguage = array(
	array('vn','Việt Nam'),
	array('en','English')

);

?>

